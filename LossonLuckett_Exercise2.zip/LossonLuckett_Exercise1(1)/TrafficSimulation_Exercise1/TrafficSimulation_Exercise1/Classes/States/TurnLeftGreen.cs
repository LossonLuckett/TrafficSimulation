﻿using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
using TrafficSimulation_Exercise1.Classes.Interfaces;
namespace TrafficSimulation_Exercise1.Classes.States
{
    public class TurnLeftGreen : IState
    {

        private readonly Vehicle _vehicle;

        public TurnLeftGreen(Vehicle vehicle)
        {
            _vehicle = vehicle;
        }

        public void MovingForward()
        {
            Console.WriteLine("The vehicle can only move forward on Green or Yellow lights");
        }
        public void TurningLeft()
        {
            Console.WriteLine("The vehicle is turning left.");
            _vehicle.currentState = new GreenLight(_vehicle);
            _vehicle.previousAction = VehicleActions.Left;
        }
        public void TurningRight()
        {
            Console.WriteLine("The vehicle cannot turn right on a Left Turn Green light.");
        }
        public void Action()
        {

        }
    }
}
