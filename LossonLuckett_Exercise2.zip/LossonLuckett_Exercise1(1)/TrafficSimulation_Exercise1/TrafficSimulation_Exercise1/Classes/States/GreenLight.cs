﻿using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;


namespace TrafficSimulation_Exercise1.Classes.States
{
    public class GreenLight : IState
    {

        private readonly Vehicle _vehicle;

        public GreenLight(Vehicle vehicle)
        {
            _vehicle = vehicle;
        }

        public void MovingForward()
        {
            Console.WriteLine(" The vehicle is moving forward.");
            _vehicle.previousAction = VehicleActions.Forward;
            _vehicle.currentState = new GreenLight(_vehicle);
        }
        public void TurningLeft()
        {
            throw new Exception("The vehicle can only turn left on a Left Turn Green Light.");
        }
        public void TurningRight()
        {
            Console.WriteLine("The vehicle is turning right.");
            _vehicle.previousAction = VehicleActions.Right;
            _vehicle.currentState = new GreenLight(_vehicle);
        }
        public void Action()
        {
            
        }
    }
}
