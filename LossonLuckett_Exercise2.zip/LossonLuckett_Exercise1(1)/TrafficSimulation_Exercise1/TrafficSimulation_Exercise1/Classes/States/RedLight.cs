﻿using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
using TrafficSimulation_Exercise1.Classes.States;

namespace TrafficSimulation_Exercise1.Classes
{
    public class RedLight : IState
    {
        private readonly Vehicle _vehicle;

        public RedLight(Vehicle vehicle)
        {
            _vehicle = vehicle;
        }

        public void MovingForward()
        {
            throw new Exception("The Light is RED the vehicle cannot move forward.");
        }
        public void TurningLeft()
        {
            throw new Exception("The vehicle can only turn left on a Left Turn Green Light.");
        }
        public void TurningRight()
        {
            Console.WriteLine("The vehicle is turning right.");
            _vehicle.currentState = new GreenLight(_vehicle);
            _vehicle.previousAction = VehicleActions.Right;
        }
        public void Action()
        {
           
        }



    }
}
