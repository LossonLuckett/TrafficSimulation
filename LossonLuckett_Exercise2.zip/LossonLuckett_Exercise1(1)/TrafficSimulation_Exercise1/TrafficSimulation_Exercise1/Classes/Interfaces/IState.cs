﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficSimulation_Exercise1.Classes.Interfaces
{
    public interface IState
    {
        public void MovingForward();
        public void TurningLeft();
        public void TurningRight();
        public abstract void Action();

    }
}
