﻿using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes.States;

namespace TrafficSimulation_Exercise1.Classes.VehicleAbstraction
{
    public enum VehicleActions
    {
        NoAction, Forward, Action, Left, Right
    }
    public class Vehicle
    {
        public IState currentState { get; set; }

        public IState redLight { get; set; }

        public IState greenLight { get; set; }

        public IState yellowLight { get; set; }

        public IState leftTurnGreen { get; set; }

        public VehicleActions previousAction { get; set; } 

        

        public Vehicle()
        {
            redLight = new RedLight(this);
            greenLight = new GreenLight(this);
            yellowLight = new YellowLight(this);
            leftTurnGreen = new TurnLeftGreen(this);
            

            currentState = greenLight; 
        }

        public void TurningLeft()
        {
            checkAction();
            currentState.TurningLeft();
        }
        public void TurningRight()
        {
            checkAction();
            currentState.TurningRight();       
        }
        public void MovingForward()
        {
            checkForward();
            currentState.MovingForward();
        }

        virtual public void Action()
        {
            //Method defined in Vehicle Type Classes
                      
        }

        public void checkAction()
        {
            if (previousAction == VehicleActions.Action)
            {
                throw new Exception(" You can only move forward after this action.");
            }
        }

        public void checkForward()
        {
            if (previousAction == VehicleActions.Forward)
            {
                throw new Exception("The vehicles is already moving forward.");
            }
        }

        virtual public void CheckVehicleType()
        {
            
        }
    }
}
