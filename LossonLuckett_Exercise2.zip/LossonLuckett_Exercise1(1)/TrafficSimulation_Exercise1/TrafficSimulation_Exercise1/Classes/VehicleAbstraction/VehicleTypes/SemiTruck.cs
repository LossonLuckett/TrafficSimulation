﻿using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.Interfaces;
namespace TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes
{
    public class SemiTruck : Vehicle
    {
        override public void Action()
        {
            checkAction();
            Console.WriteLine("The Semi Truck has Jack Knifed to a stop");
            currentState = greenLight;
            previousAction = VehicleActions.Action;
        }
        override public void CheckVehicleType()
        {
            Console.WriteLine("You are in a semi truck.");
        }

   


    }
}
