﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes
{
    public class SUV : Vehicle
    {
        override public void Action()
        {
            if (previousAction == VehicleActions.Forward)
            {
                Console.WriteLine("The SUV has run over a Ford Pinto");
                currentState = greenLight;
                previousAction = VehicleActions.Action;
            }
            else
            {
                throw new Exception("The SUV can only run over a Ford Pinto, if its previous action was MovingForward.");
            }
        }
        override public void CheckVehicleType()
        {
            Console.WriteLine("You are in an SUV.");
        }

    }
}
