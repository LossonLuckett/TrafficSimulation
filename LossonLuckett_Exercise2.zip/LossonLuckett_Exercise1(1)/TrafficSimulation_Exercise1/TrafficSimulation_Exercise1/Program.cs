﻿using System;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
namespace TrafficSimulation_Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            Vehicle semi = new SemiTruck();
               




        }
    }
}
