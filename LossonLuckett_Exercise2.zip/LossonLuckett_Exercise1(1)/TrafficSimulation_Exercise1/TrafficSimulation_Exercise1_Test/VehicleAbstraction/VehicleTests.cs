﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes;
using TrafficSimulation_Exercise1.Classes.States;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes;

namespace TrafficSimulation_Exercise1_Test.VehicleAbstraction
{
    
    [TestFixture]
    public class VehicleTests
    {


    }
}
