﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes;
using TrafficSimulation_Exercise1.Classes.States;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes;

namespace TrafficSimulation_Exercise1_Test.VehicleAbstraction
{

    [TestFixture]
    public class SemiTruckTests
    {
        [Test]
        public void TestForErrorAfterGivingMoveForwardCommand_WhileAlreadyMovingForwardMoving()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.MovingForward();
            Assert.Throws<Exception>(() => SemiTruck.MovingForward());
        }


        [Test]
        public void TestForErrorWhenTurningLeft_WhileInGreenLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            Assert.Throws<Exception>(() => SemiTruck.TurningLeft());
        }

        [Test]
        public void TestForErrorWhenTurningLeft_WhileInRedLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.redLight;
            Assert.Throws<Exception>(() => SemiTruck.TurningLeft());
        }

        [Test]
        public void TestForTurningLeft_WhileInLeftTurnGreenState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.leftTurnGreen;
            SemiTruck.TurningLeft();
        }

        [Test]
        public void TestForTurningLeft_WhileInYellowLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.yellowLight;
            Assert.Throws<Exception>(() => SemiTruck.TurningLeft());
        }

        [Test]
        public void TestForMovingForward_AfterActionCommand()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.Action();
            SemiTruck.MovingForward();
        }

        [Test]
        public void TestForTurningLeft_AfterActionCommand()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.Action();
            Assert.Throws<Exception>(() => SemiTruck.TurningLeft());
        }

        [Test]
        public void TestForTurningRight_AfterActionCommand()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.Action();
            Assert.Throws<Exception>(() => SemiTruck.TurningRight());
        }

        [Test]
        public void TestForActionCommand_AfterActionCommand()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.Action();
            Assert.Throws<Exception>(() => SemiTruck.Action());
        }

        [Test]
        public void TestForGreenLightState_AfterMovingForwardWhileInYellowLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.yellowLight;
            SemiTruck.MovingForward();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForCheckGreenLightState_AfterMovingForwardWhileInGreenLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.MovingForward();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningLeftWhileInTurnLeftGreenState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.leftTurnGreen;
            SemiTruck.TurningLeft();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInRedLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.redLight;
            SemiTruck.TurningRight();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInYellowLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.currentState = SemiTruck.yellowLight;
            SemiTruck.TurningRight();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInGreenLightState()
        {
            Vehicle SemiTruck = new SemiTruck();
            SemiTruck.TurningRight();
            Assert.AreEqual(SemiTruck.currentState.GetType(), typeof(GreenLight));
        }
    }
}
