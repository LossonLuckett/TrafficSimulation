﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction;
using TrafficSimulation_Exercise1.Classes.VehicleAbstraction.VehicleTypes;
using TrafficSimulation_Exercise1.Classes.States;
using TrafficSimulation_Exercise1.Classes.Interfaces;
using TrafficSimulation_Exercise1.Classes;

namespace TrafficSimulation_Exercise1_Test.VehicleAbstraction
{

    [TestFixture]
    public class SUVTests
    {
        [Test]
        public void TestForErrorAfterGivingMoveForwardCommand_WhileAlreadyMovingForwardMoving()
        {
            Vehicle SUV = new SUV();
            SUV.MovingForward();
            Assert.Throws<Exception>(() => SUV.MovingForward());
        }


        [Test]
        public void TestForErrorWhenTurningLeft_WhileInGreenLightState()
        {
            Vehicle SUV = new SUV();
            Assert.Throws<Exception>(() => SUV.TurningLeft());
        }

        [Test]
        public void TestForErrorWhenTurningLeft_WhileInRedLightState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.redLight;
            Assert.Throws<Exception>(() => SUV.TurningLeft());
        }

        [Test]
        public void TestForTurningLeft_WhileInLeftTurnGreenState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.leftTurnGreen;
            SUV.TurningLeft();
        }

        [Test]
        public void TestForTurningLeft_WhileInYellowLightState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.yellowLight;
            Assert.Throws<Exception>(() => SUV.TurningLeft());
        }

         [Test]
         public void TestForMovingForward_BeforeActionCommand()
        {
            Vehicle SUV = new SUV();
            SUV.MovingForward();
            SUV.Action();
        }

        [Test]
        public void TestForTurningLeft_BeforeActionCommand()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.leftTurnGreen;
            SUV.TurningLeft();
            Assert.Throws<Exception>(() => SUV.Action());
        }

        [Test]
        public void TestForTurningRight_BeforeActionCommand()
        {
            Vehicle SUV = new SUV();
            SUV.TurningRight();
            Assert.Throws<Exception>(() => SUV.Action());
        }

        [Test]
        public void TestForActionCommand_BeforeActionCommand()
        {
            Vehicle SUV = new SUV();
            SUV.MovingForward();
            SUV.Action();
            Assert.Throws<Exception>(() => SUV.Action());
        }


        [Test]
        public void TestForGreenLightState_AfterMovingForwardWhileInYellowLightState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.yellowLight;
            SUV.MovingForward();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForCheckGreenLightState_AfterMovingForwardWhileInGreenLightState()
        {
            Vehicle SUV = new SUV();
            SUV.MovingForward();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningLeftWhileInTurnLeftGreenState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.leftTurnGreen;
            SUV.TurningLeft();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInRedLightState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.redLight;
            SUV.TurningRight();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInYellowLightState()
        {
            Vehicle SUV = new SUV();
            SUV.currentState = SUV.yellowLight;
            SUV.TurningRight();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }

        [Test]
        public void TestForGreenLightState_AfterTurningRightInGreenLightState()
        {
            Vehicle SUV = new SUV();
            SUV.TurningRight();
            Assert.AreEqual(SUV.currentState.GetType(), typeof(GreenLight));
        }
    }
}
